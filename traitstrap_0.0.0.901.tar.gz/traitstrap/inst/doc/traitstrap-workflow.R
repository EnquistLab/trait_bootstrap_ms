## ---- setup, include = FALSE--------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

library(traitstrap)
library(dplyr)
library(ggplot2)

theme_set(theme_minimal(base_size = 12))

## ----hex, echo=FALSE, out.width='15%', out.extra='style="float:right; padding:8px"'----
knitr::include_graphics("../man/figures/Traitstrap_hex.png")

## ----true-dist, echo=FALSE, out.width='90%'-----------------------------------
knitr::include_graphics("true-dist.png")

## ----comm-boot, echo=FALSE, out.width='90%'-----------------------------------
knitr::include_graphics("comm-boot.png")

## ----data-prank, echo=FALSE, eval=TRUE----------------------------------------
community <- community %>% 
  mutate(Taxon = case_when(Taxon == "equisetum scirpoides" ~ "enquistetum scirpoides",
                           Taxon == "micranthes hieracifolia" ~ "maitneranthes hieracifolia",
                           Taxon == "bistorta vivipara" ~ "bistorta vigdis",
                           Taxon == "stellaria humifusa" ~ "stelfordaria humifusa",
                           Taxon == "oxyria digyna" ~ "oxyria tanyna",
                           Taxon == "silene acaulis" ~ "silene acaudis",
                           TRUE ~ Taxon
                           ))

trait <- trait %>% 
  mutate(Taxon = case_when(Taxon == "equisetum scirpoides" ~ "enquistetum scirpoides",
                           Taxon == "micranthes hieracifolia" ~ "maitneranthes hieracifolia",
                           Taxon == "bistorta vivipara" ~ "bistorta vigdis",
                           Taxon == "stellaria humifusa" ~ "stelfordaria humifusa",
                           Taxon == "oxyria digyna" ~ "oxyria tanyna",
                           Taxon == "silene acaulis" ~ "silene acaudis",
                           TRUE ~ Taxon
                           ))

## ----comm-data, echo=FALSE, eval=TRUE-----------------------------------------
community

## ----trait-data, echo=FALSE, eval=TRUE----------------------------------------
trait

## ----trait-impute, echo=TRUE, eval=TRUE---------------------------------------

trait_imputation <- trait_impute(
    # input data (mandatory)
    comm = community,
    traits = trait,
    
    # specifies columns in your data (mandatory)
    abundance_col = "Cover",
    taxon_col = "Taxon",
    trait_col = "Trait",
    value_col = "Value",
    
    # specifies sampling hierarchy
    scale_hierarchy = c("Site", "PlotID"),
    
    # min number of samples
    min_n_in_sample = 9
  )

trait_imputation

## ----trait-impute2, echo=TRUE, eval=FALSE-------------------------------------
#  
#  trait_imputation2 <- trait_impute(
#      comm = community,
#      traits = trait,
#  
#      abundance_col = "Cover",
#  
#      # defining taxonomic hierarchy
#      taxon_col = c("Taxon", "Genus"),
#  
#      trait_col = "Trait",
#      value_col = "Value",
#  
#      scale_hierarchy = c("Site", "PlotID"),
#      min_n_in_sample = 3
#  
#      # specifying experimental design
#      treatment_col = "Treatment",
#      treatment_level = "Site",
#  
#    )

## ----non-parap-boot, echo=TRUE, eval=TRUE-------------------------------------

# run nonparametric bootstrapping
np_bootstrapped_moments <- trait_np_bootstrap(
  trait_imputation, 
  nrep = 200
  )

np_bootstrapped_moments

## ----summarize, echo=TRUE, eval=TRUE------------------------------------------

# summarizes bootstrapping output
sum_boot_moment <- trait_summarise_boot_moments(
  np_bootstrapped_moments
  )

sum_boot_moment

## ----fit-dist, echo=TRUE, eval=TRUE-------------------------------------------

# fit distributions
fitted_distributions <- trait_fit_distributions(
  imputed_traits = trait_imputation,
  distribution_type = "lognormal"
  )

fitted_distributions

## ----fit-dist2, echo=TRUE, eval=FALSE-----------------------------------------
#  
#  # fit several types of distributions
#  fitted_distributions <- trait_fit_distributions(
#    imputed_traits = trait_imputation,
#    distribution_type = list(Plant_Height_cm = "normal", Wet_Mass_g = "lognormal")
#    )
#  
#  fitted_distributions

## ----para-boot, echo=TRUE, eval=TRUE------------------------------------------

# run parametric bootstrapping
p_bootstrapped_moments <- trait_parametric_bootstrap(
    fitted_distributions = fitted_distributions, 
    nrep = 200
    )

p_bootstrapped_moments

## ----raw-dist-np, echo=TRUE, eval=TRUE----------------------------------------

# run nonparametric bootstrapping
raw_dist_np <- trait_np_bootstrap(
  trait_imputation,
  raw = TRUE
  )

raw_dist_np

## ----plot-raw-dist-np, echo=TRUE, eval=TRUE, fig.width = 6--------------------

ggplot(raw_dist_np, aes(x = log(Value), fill = Site)) +
  geom_density(alpha = 0.4) +
  scale_fill_viridis_d(end = 0.9, option = "plasma") +
  labs(x = "log(trait value)") +
  facet_wrap( ~ Trait, scales = "free")


## ----coverage-plot, echo=TRUE, eval=TRUE, fig.width = 6-----------------------

# show coverage plot
autoplot(trait_imputation) + 
  theme(axis.text.x = element_text(size = 8, angle = 90, vjust = 0.5))


## ----missing-traits, echo=TRUE, eval=TRUE-------------------------------------

# list missing traits
trait_missing(imputed_trait = trait_imputation,
              comm = community)


