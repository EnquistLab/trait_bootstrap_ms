library(testthat)
library(traitstrap)


test_check("traitstrap")
